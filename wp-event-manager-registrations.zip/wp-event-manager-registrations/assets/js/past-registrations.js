jQuery(document).ready(function($) {
	jQuery(".event-manager-past-registrations").on( 'click', 'a.unregister-attendee', function() {
		return confirm(event_manager_registration.i18n_confirm_delete);     
	});
    jQuery("#reset_registrations").on('click', function(){
        window.location.href = window.location.href.split('?')[0];
    });
});