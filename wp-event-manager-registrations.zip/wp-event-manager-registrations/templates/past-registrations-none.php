<div class="wpem-alert wpem-alert-danger">
    <?php _e( 'You haven\'t made any registrations yet!', 'wp-event-manager-registrations' ); ?>
</div>