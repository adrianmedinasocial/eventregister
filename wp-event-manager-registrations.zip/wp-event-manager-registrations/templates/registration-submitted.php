<p class="event-manager-message wpem-alert wpem-alert-success">
	<i class="wpem-icon-user-check"></i>  
	<?php _e( 'Your event registration has been submitted successfully.', 'wp-event-manager-registrations' ); ?>
</p>