<div class="updated">
	<p><?php printf( __('Your licence for <strong>%s</strong> has been activated. Thanks!', 'wp-event-manager-registrations'), esc_html( $this->plugin_data['Name'] ) ); ?></p>
</div>