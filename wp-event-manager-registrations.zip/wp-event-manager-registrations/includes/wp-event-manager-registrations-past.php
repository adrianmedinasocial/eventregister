<?php
/**
 * WP_Event_Manager_Registrations_Past class.
 */
if ( ! defined( 'ABSPATH' ) ) {	exit;}

class WP_Event_Manager_Registrations_Past {
	/**
	 * Constructor
	 */
	function __construct() {
 		add_shortcode( 'past_registrations', array( $this, 'past_registrations' ) );
 		add_shortcode( 'my_registrations', array( $this, 'past_registrations' ) );
    }

    /**
     * Past Registrations
     */
    public function past_registrations( $atts ) {
        
        //add js for confirmation dialog for unregister user
        wp_register_script( 'wp-event-manager-past-registrations', EVENT_MANAGER_REGISTRATIONS_PLUGIN_URL . '/assets/js/past-registrations.min.js', array( 'jquery' ), EVENT_MANAGER_REGISTRATIONS_VERSION, true );
        
        wp_localize_script( 'wp-event-manager-past-registrations', 'event_manager_registration', array(
            'i18n_confirm_delete'         => __( 'Are you sure you want to unregister? There is no option to undo.', 'wp-event-manager-registrations' )
        ) );
        wp_enqueue_script( 'wp-event-manager-past-registrations' );
        
    	// If user is not logged in, abort
    	if ( ! is_user_logged_in() ) {
			do_action( 'event_manager_event_registrations_past_registration_login' );
			
			ob_start();
			if ( get_option( 'wp_event_manager_version' ) > '3.1.13' ) {
				get_event_manager_template( 'sign-in-link.php' );
			} else{
				get_event_manager_template( 
					'registration-form-login.php', 
					array(), 
					'wp-event-manager-registrations', 
					EVENT_MANAGER_REGISTRATIONS_PLUGIN_DIR . '/templates/'
				);
			}
			return ob_get_clean();
		}
		
		if ( isset($_REQUEST['unregister']) && ! empty( $_REQUEST['unregister'] ) ) {
			$registration_id = $_REQUEST['unregister'];
			//send mail to organizer of event
			$registration = get_post($registration_id);

			if( isset($registration->post_type) && $registration->post_type !== 'event_registration')
				return;
	
			$event_id = $registration->post_parent;
			$event = get_post($event_id);
			$attendee_name = $registration->post_title;
			$attendee_email = get_post_meta($registration_id, '_attendee_email', true);
	
			$registration_fields = get_event_registration_form_fields();
			  
			if(isset($attendee_email) && empty($attendee_email) ){
				foreach ($registration_fields as $key => $field) {
					if(in_array('from_email', $field['rules'])){
						$attendee_email = isset($_REQUEST[$key]) ? $_REQUEST[$key] : '';
					}
				}
			}
			 
			$meta = [];
			foreach ($registration_fields as $key => $field) {
				$value = get_post_meta($registration_id, $key, true);
				if(!empty($value)){
					$meta[$key] = $value;   
				}               
			}
	
			if(empty($meta)){
				$meta = $_REQUEST;
			}
			
			$organizer_notification = apply_filters('send_unregistratoin_organizer_email_notifications', get_option('enable_unregister_attendee_organizer_email', true));
        	if ($organizer_notification) {
           
			//get organizer info
			$organizer_info = get_oragnizer_registration_email_notification($event_id, $event );
				
			if ( isset($organizer_info) && !empty($organizer_info)) {
					$existing_shortcode_tags = $GLOBALS['shortcode_tags'];
					remove_all_shortcodes();
					event_registration_email_add_shortcodes(array(
						'registration_id'       => $registration_id,
						'event_id'              => $event_id,
						'user_id'               => get_current_user_id(),
						'attendee_name'         => $attendee_name,
						'attendee_email'        => $attendee_email,
						'meta'                  => $meta
					));
					$subject = do_shortcode(get_attendee_unregistration_organizer_email_subject());
					$message = do_shortcode(get_attendee_unregistration_organizer_email_content());
					wpem_send_registration_email($organizer_info['organizer_email'], $subject, $message, $existing_shortcode_tags, 'organizer', $registration_id);
					$GLOBALS['shortcode_tags'] = $existing_shortcode_tags;
				}
        	}

			wp_delete_post( $registration_id );
		}

		extract( shortcode_atts( array(
			'posts_per_page' => '25',
		), $atts ) );
		
    	$args = apply_filters( 'event_manager_event_registrations_past_args', array(
			'post_type'           => 'event_registration',
			'post_status'         => array_keys( get_event_registration_statuses() ),
			'posts_per_page'      => $posts_per_page,
			'offset'              => ( max( 1, get_query_var('paged') ) - 1 ) * $posts_per_page,
			'orderby'             => 'publish_date',
			'order'               => 'DESC',
			'ignore_sticky_posts' => 1,
		) );

		if(isset($_GET['search_keywords']) && !empty($_GET['search_keywords'])){
			$args['meta_query'] = array(
				'relation' => 'AND',
				array(
					'key' => '_attendee_user_id',
					'value' => get_current_user_id(),
					'compare' => '=',
				),
				array(
					'key'     => '_event_registered_for',
					'value'   => $_GET['search_keywords'],
					'compare' => 'LIKE'
				)
			);
		}else{
			$args['meta_query'] = array(
				array(
					'key' => '_attendee_user_id',
					'value' => get_current_user_id(),
					'compare' => '=',
				)
			);
		}

		$registrations = new WP_Query( $args );

		ob_start();

		if ( $registrations->have_posts() ) {
			get_event_manager_template( 'past-registrations.php', array( 'registrations' => $registrations->posts, 'max_num_pages' => $registrations->max_num_pages ), 'wp-event-manager-registrations', EVENT_MANAGER_REGISTRATIONS_PLUGIN_DIR . '/templates/' );
		} else {
			get_event_manager_template( 'past-registrations-none.php', array(), 'wp-event-manager-registrations', EVENT_MANAGER_REGISTRATIONS_PLUGIN_DIR . '/templates/' );
		}
		return ob_get_clean();
    }
}
new WP_Event_Manager_Registrations_Past();
